package br.com.DablioW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DablioWApplication {

	public static void main(String[] args) {
		SpringApplication.run(DablioWApplication.class, args);
	}

}
