package br.com.DablioW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DablioWApplicationTests {

	@Test
	void contextLoads() {
	}

}
